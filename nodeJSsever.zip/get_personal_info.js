const { UniversalRequestClient } = require('./api_client_version_all_app');

async function getPersonalInfo() {
    const client = new UniversalRequestClient('taqu');
    
    return await client.post({
        url: 'https://gw-cn.jiaoliuqu.com/live_api/v1/Insignia/getAllInsigniaList',
        data: {
            account_uuid: 'bhebdgdgfaahjdeh', // bhebdgdgfaahjdeh #p7ywz34omr6 #cfg8vt0trtij #bhfidabagaaaabfa
            ticket_id: 'eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3MjkzMTMzNjAsInV1aWQiOiJjZmdmbHZzNTU3aW4iLCJhcHBfY29kZSI6MSwiY2xvbmVkIjoxfQ.uWniU_utqvEexV0X9TtUSUtW0jdquGPlpKbMiACiym0'
        }
    });
}

// 主函数
async function main() {
    try {
        const result = await getPersonalInfo();
        
        // 提取特定徽章信息
        if (result && result.info && result.info.data) {
            const insigniaList = result.info.data.list;
            
            // 遍历所有徽章类别
            let found = false;
            for (const category of insigniaList) {
                // 遍历当前类别中的所有徽章
                for (const insignia of category.member) {
                    // 查找标题为"高富帅"的徽章
                    if (insignia.title === '高富帅') {
                        console.log(`徽章介绍: ${insignia.introduce}`);
                        console.log(`进度: ${insignia.schedule}`);
                        found = true;
                        break;
                    }
                }
                if (found) break;
            }
            
            if (!found) {
                console.log('未找到"高富帅"徽章');
            }
        } else {
            console.log('未能获取到徽章数据');
        }
    } catch (error) {
        console.error('发生错误:', error);
    }
}

// 执行主函数
if (require.main === module) {
    main();
}

module.exports = { getPersonalInfo };