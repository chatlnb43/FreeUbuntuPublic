const crypto = require('crypto');
const https = require('https');
const http = require('http');
const { URL } = require('url');

/**
 * 动态认证参数生成器
 */
class DynamicAuthGenerator {
    constructor(secret, deviceToken) {
        this._secret = secret;
        this._deviceToken = deviceToken;
    }

    /**
     * 随机打乱并截取特定长度的字符串
     */
    static randomKey(length) {
        const chars = "QWERTYUIOPASDFGHJKLZXCVBNM".split('');
        // Fisher-Yates 洗牌算法
        for (let i = chars.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [chars[i], chars[j]] = [chars[j], chars[i]];
        }
        return chars.slice(0, length).join('');
    }

    /**
     * 计算md5值
     */
    static md5(text) {
        return crypto.createHash('md5').update(text).digest('hex');
    }

    /**
     * 生成密钥
     */
    generateKeys() {
        const key = DynamicAuthGenerator.randomKey(16);
        const tKeyList = ["KFDM", "SEFD", "VFRS", "GRSW"];
        
        return {
            xkey: key.substring(0, 4),
            hkey: key.substring(4, 8),
            ikey: key.substring(8, 12),
            okey: key.substring(12, 16),
            tkey: tKeyList[Math.floor(Math.random() * tKeyList.length)]
        };
    }

    /**
     * 获取认证值
     */
    getAuthValue(xkey, hkey, ikey, okey, tkey) {
        const o = {};
        o[xkey[1]] = xkey;
        o[hkey[1]] = hkey;
        o[ikey[1]] = ikey;
        o[okey[1]] = okey;

        const a = Object.keys(o).sort().reverse();
        let s = 0;
        let c = "";

        for (const e of a) {
            const condition = (
                (tkey !== "KFDM" || (s !== 0 && s !== 1)) &&
                (tkey !== "SEFD" || (s !== 1 && s !== 3)) &&
                (tkey !== "VFRS" || (s !== 0 && s !== 2)) &&
                (tkey !== "GRSW" || (s !== 0 && s !== 2 && s !== 3))
            );
            
            if (!condition) {
                c += o[e];
            }
            s += 1;
        }

        return c;
    }

    /**
     * 生成所有动态认证参数
     */
    generateDynamicAuth() {
        // 生成时间戳
        const startTime = Date.now();
        const timestamp = `${startTime}${Math.floor(Math.random() * 900000) + 100000}`;
        const timestampShort = `${startTime}000`;

        // 生成密钥
        const keys = this.generateKeys();

        // 获取认证值
        const authValue = this.getAuthValue(
            keys.xkey, keys.hkey, keys.ikey, keys.okey, keys.tkey
        );

        // 生成校验签名
        const validSignature = 
            DynamicAuthGenerator.md5(`${this._secret}${timestamp}${authValue}`) +
            DynamicAuthGenerator.md5(`${this._secret}${this._deviceToken}${authValue}`);

        return {
            time: timestamp,
            tp: timestampShort,
            vaild: validSignature,
            tkey: keys.tkey,
            ikey: keys.ikey,
            hkey: keys.hkey,
            xkey: keys.xkey,
            okey: keys.okey
        };
    }
}

/**
 * 固定请求配置
 */
class FixedRequestConfig {
    constructor(configType = "taqu") {
        // 固定配置
        this.timeout = 30000;
        this.appid = "2001";
        this.secret = "a9b32d0abb396a6805353dd97c0cb76f";
        this.baseParams = { rise_in: "f2e" };

        // 根据不同类型设置不同配置
        if (configType === "miyou") {
            this.deviceToken = "BA8CCD96-1F89-4F65-800E-F2437A6E1C93";
            this.appVersion = "11133";
            this.ch = "appstore_plus";
            this.cl = "4";
            this.abbi = "4_1";
            this.du = "2025012153-18.0.1";
            this.abep = "267_945,579_1684,275_964,187_619,231_808,750_2100,116_388,230_806,387_1205,408_1261,440_1350";
            this.appName = "MiYou";
            this.sx = "1";
        } else if (configType === "miyounv") {
            this.deviceToken = "CBEB6132-9F8C-4F1D-B8B9-71586A73231A";
            this.appVersion = "11150";
            this.ch = "appstore_plus";
            this.cl = "4";
            this.abbi = "4_1";
            this.du = "11150-18.0.1";
            this.abep = "267_945,579_1684,275_964,116_388,776_2174,387_1205,188_623,440_1350";
            this.appName = "MiYou";
            this.sx = "2";
        } else { // taqu
            this.deviceToken = "83CAC81D-1E1D-45E6-9DFB-A57677333C5D";
            this.appVersion = "11240";
            this.ch = "appstore";
            this.cl = "1";
            this.abbi = "1_0,1_0,1_0,4_1";
            this.du = "2025011663-18.0.1";
            this.abep = "650_1865,765_2140,275_964,548_1613,187_619,529_1563,181_600,741_2080,466_1416,379_1187,579_1684,745_2088,520_1542,567_1658,440_1350,772_2165";
            this.appName = "TaQu";
            this.sx = "1";
        }

        // 固定请求头参数
        this.fixedHeaders = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'ch': this.ch,
            'av': this.appVersion,
            'abep': this.abep,
            'ap': '1',
            'sx': this.sx,
            'cl': this.cl,
            'accept-language': 'zh-Hans-CN;q=1',
            'ac': 'WIFI',
            'abbi': this.abbi,
            'ov': '18.0.1',
            'du': this.du,
            'pl': 'iphone'
        };
    }

    /**
     * 获取User-Agent
     */
    getUserAgent() {
        return `${this.appName}/${this.appVersion}/iPhone/${this.deviceToken}`;
    }

    /**
     * 获取固定请求头(不包含动态参数)
     */
    getFixedHeaders() {
        const headers = { ...this.fixedHeaders };
        headers['User-Agent'] = this.getUserAgent();
        headers['appid'] = this.appid;
        headers['to'] = this.deviceToken;
        return headers;
    }
}

/**
 * 通用请求客户端
 */
class UniversalRequestClient {
    constructor(configType = "taqu") {
        this.config = new FixedRequestConfig(configType);
        this.authGenerator = new DynamicAuthGenerator(
            this.config.secret,
            this.config.deviceToken
        );
    }

    /**
     * 生成随机字符串
     */
    static randomString(length = 32) {
        const chars = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678";
        let result = "";
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    /**
     * 创建完整的请求头
     */
    createRequestHeaders() {
        // 获取固定请求头
        const headers = this.config.getFixedHeaders();

        // 生成动态认证参数
        const dynamicAuth = this.authGenerator.generateDynamicAuth();

        // 合并动态参数到请求头
        return { ...headers, ...dynamicAuth };
    }

    /**
     * 原生 HTTP/HTTPS 请求封装
     */
    _httpRequest(options, postData = null) {
        return new Promise((resolve, reject) => {
            const protocol = options.protocol === 'https:' ? https : http;
            
            const req = protocol.request(options, (res) => {
                let data = '';

                res.on('data', (chunk) => {
                    data += chunk;
                });

                res.on('end', () => {
                    try {
                        const result = JSON.parse(data);
                        resolve({ status: res.statusCode, data: result });
                    } catch (e) {
                        resolve({ status: res.statusCode, data: data });
                    }
                });
            });

            req.on('error', (error) => {
                reject(error);
            });

            req.on('timeout', () => {
                req.destroy();
                reject(new Error('Request timeout'));
            });

            // 发送POST数据
            if (postData) {
                req.write(postData);
            }

            req.end();
        });
    }

    /**
     * 通用请求方法
     */
    async makeRequest(url, params = null, data = null, method = 'GET', showLoading = true, customHeaders = null) {
        // 生成请求头
        let headers = this.createRequestHeaders();

        // 合并自定义请求头
        if (customHeaders) {
            headers = { ...headers, ...customHeaders };
        }

        // 基础URL参数
        const urlParams = {
            distinctRequestId: UniversalRequestClient.randomString(32).toLowerCase()
        };

        // 添加自定义URL参数
        if (params) {
            Object.assign(urlParams, params);
        }

        // POST请求的body数据
        let postData = {};
        if (data) {
            Object.assign(postData, data);
            // 确保POST数据中也有ticket_id(如果URL参数中有的话)
            if (urlParams.ticket_id && !postData.ticket_id) {
                postData.ticket_id = urlParams.ticket_id;
            }
        }

        try {
            if (showLoading) {
                console.log("Loading...");
            }

            // 解析URL
            const urlObj = new URL(url);
            
            // 添加查询参数
            Object.keys(urlParams).forEach(key => {
                urlObj.searchParams.append(key, urlParams[key]);
            });

            // 准备POST数据
            let postDataString = null;
            if (method.toUpperCase() === 'POST') {
                const formParams = new URLSearchParams(Object.keys(postData).length > 0 ? postData : urlParams);
                postDataString = formParams.toString();
                headers['Content-Length'] = Buffer.byteLength(postDataString);
            }

            // 构建请求选项
            const options = {
                protocol: urlObj.protocol,
                hostname: urlObj.hostname,
                port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80),
                path: urlObj.pathname + urlObj.search,
                method: method.toUpperCase(),
                headers: headers,
                timeout: this.config.timeout
            };

            // 发送请求
            const response = await this._httpRequest(options, postDataString);

            // 处理响应
            if (response.status === 200) {
                console.log("Response received successfully");
                return response.data;
            } else {
                const errorMsg = `HTTP Error: ${response.status}`;
                console.error(errorMsg);
                return { error: errorMsg, status_code: response.status };
            }

        } catch (error) {
            const errorMsg = `Request Error: ${error.message}`;
            console.error(errorMsg);
            return { error: errorMsg };
        } finally {
            if (showLoading) {
                console.log("Loading finished.");
            }
        }
    }

    /**
     * GET请求的便捷方法
     */
    async get(url, params = null, showLoading = true, customHeaders = null) {
        return this.makeRequest(url, params, null, 'GET', showLoading, customHeaders);
    }

    /**
     * POST请求的便捷方法
     */
    async post({ url, params = null, data = null, showLoading = true, customHeaders = null }) {
        return this.makeRequest(url, params, data, 'POST', showLoading, customHeaders);
    }
}

/**
 * 格式化打印JSON数据
 */
function printJsonFormatted(data) {
    console.log("\n" + "=".repeat(60));
    console.log("API响应结果:");
    console.log("=".repeat(60));
    if (typeof data === 'object') {
        console.log(JSON.stringify(data, null, 2));
    } else {
        console.log(data);
    }
    console.log("=".repeat(60));
}

/**
 * 创建客户端实例的便捷函数
 */
function createClient(configType = "taqu") {
    return new UniversalRequestClient(configType);
}

/**
 * 快速GET请求函数
 */
async function quickGetRequest(url, params = null, showLoading = false, configType = "taqu") {
    const client = new UniversalRequestClient(configType);
    return client.get(url, params, showLoading);
}

/**
 * 快速POST请求函数
 */
async function quickPostRequest(url, params = null, data = null, showLoading = false, configType = "taqu") {
    const client = new UniversalRequestClient(configType);
    return client.post({ url, params, data, showLoading });
}

// 导出模块
module.exports = {
    DynamicAuthGenerator,
    FixedRequestConfig,
    UniversalRequestClient,
    printJsonFormatted,
    createClient,
    quickGetRequest,
    quickPostRequest
};

// 使用示例 - 仅当直接运行此文件时执行
if (require.main === module) {
    (async () => {
        console.log("=== MiYou 签到请求示例 ===");

        // 创建MiYou配置的客户端
        const client = new UniversalRequestClient("miyou");

        const data = {
            ticket_id: 'eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3MzY0MjAzMzEsInV1aWQiOiJiaGJoZWloY2poY2NpY2ViIiwiYXBwX2NvZGUiOjEsImNsb25lZCI6NH0.p9V1FqzWfwxQberDFLBxNTUW10-IMFbDqQtWcaIoZFY',
            token: 'BA8CCD96-1F89-4F65-800E-F2437A6E1C93'
        };

        const result = await client.post({
            url: 'https://gw-cn.jiaoliuqu.com/bbs/v5/Sign/doDailySignInV4',
            data: data,
            showLoading: true
        });

        printJsonFormatted(result);

        console.log("\n" + "=".repeat(80) + "\n");

        console.log("=== TaQu 配置测试 ===");
        const clientTaqu = new UniversalRequestClient("taqu");

        const params = {
            ticket_id: 'eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3MjkzMTMzNjAsInV1aWQiOiJjZmdmbHZzNTU3aW4iLCJhcHBfY29kZSI6MSwiY2xvbmVkIjoxfQ.uWniU_utqvEexV0X9TtUSUtW0jdquGPlpKbMiACiym0',
            other_account_uuid: 'bgijdbhhjbajceid'
        };

        const result2 = await clientTaqu.get(
            'https://gw-cn.jiaoliuqu.com/bbs/v5/Account/getPersonalExtra',
            params,
            true
        );

        printJsonFormatted(result2);
    })();
}