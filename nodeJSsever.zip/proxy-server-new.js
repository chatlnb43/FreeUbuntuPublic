// 生产环境CORS代理服务器 + 多页面托管 + 静态文件服务 + 徽章查询 (强制HTTPS)
var http = require('http');
var https = require('https');
var url = require('url');
var fs = require('fs');
var path = require('path');

// 🆕 引入徽章查询模块
var UniversalRequestClient;
try {
  UniversalRequestClient = require('./api_client_version_all_app').UniversalRequestClient;
  console.log('✅ 徽章查询模块加载成功');
} catch (error) {
  console.warn('⚠️  徽章查询模块未找到，/api/badge 功能将不可用');
  console.warn('   请确保 api_client_version_all_app.js 文件在同一目录下');
}

// 从环境变量获取端口,默认8080
var PORT = process.env.PORT || 8080;

// 是否强制HTTPS (生产环境设为true)
var FORCE_HTTPS = process.env.FORCE_HTTPS !== 'false'; // 默认true

// 定义多个API端点
var API_ENDPOINTS = {
  '/api/gift': 'https://gw-w.jiaoliuqu.com/live_api/v1/Room/accountGetRoomInfo',
  '/api/blindbox': 'https://gw-w.jiaoliuqu.com/live_trade/v1/BlindBoxWeek/index?ticket_id=eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3MjkzMTMzNjAsInV1aWQiOiJjZmdmbHZzNTU3aW4iLCJhcHBfY29kZSI6MSwiY2xvbmVkIjoxfQ.uWniU_utqvEexV0X9TtUSUtW0jdquGPlpKbMiACiym0',
  '/api/rank': 'https://gw-w.jiaoliuqu.com/live_api/v1/HostHourRank/getRankList'
};

// HTML页面路由映射
var HTML_ROUTES = {
  '/': 'index.html',
  '/index': 'index.html',
  '/rank': 'rank.html',
  '/blindbox': 'blindbox.html',
  '/gift': 'gift.html',
  '/badge': 'badge.html'  // 🆕 新增徽章查询页面
};

// 支持的静态文件扩展名及Content-Type
var STATIC_CONTENT_TYPES = {
  '.txt': 'text/plain; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.pdf': 'application/pdf',
  '.xml': 'application/xml; charset=utf-8',
  '.zip': 'application/zip'
};

// 健康检查端点
var HEALTH_CHECK_PATH = '/health';

// 🆕 徽章查询函数
async function getBadgeInfo(accountUuid, ticketId) {
  if (!UniversalRequestClient) {
    throw new Error('徽章查询模块未加载');
  }
  
  const client = new UniversalRequestClient('taqu');
  
  const result = await client.post({
    url: 'https://gw-cn.jiaoliuqu.com/live_api/v1/Insignia/getAllInsigniaList',
    data: {
      account_uuid: accountUuid,
      ticket_id: ticketId
    }
  });
  
  // 提取"高富帅"徽章信息
  if (result && result.info && result.info.data) {
    const insigniaList = result.info.data.list;
    
    for (const category of insigniaList) {
      for (const insignia of category.member) {
        if (insignia.title === '高富帅') {
          return {
            success: true,
            badge: {
              title: insignia.title,
              introduce: insignia.introduce,
              schedule: insignia.schedule,
              icon: insignia.icon || '',
              level: insignia.level || ''
            }
          };
        }
      }
    }
    
    return {
      success: false,
      error: '未找到"高富帅"徽章'
    };
  }
  
  return {
    success: false,
    error: '未能获取到徽章数据'
  };
}

var server = http.createServer(function(req, res) {
  var parsedUrl = url.parse(req.url, true);
  var requestPath = parsedUrl.pathname;
  var queryParams = parsedUrl.query;

  // 🔒 强制HTTPS检查
  if (FORCE_HTTPS) {
    var protocol = req.headers['x-forwarded-proto'] || 
                   (req.connection.encrypted ? 'https' : 'http');
    
    if (protocol !== 'https') {
      if (requestPath !== HEALTH_CHECK_PATH) {
        var host = req.headers.host || 'localhost:' + PORT;
        var httpsUrl = 'https://' + host + req.url;
        
        console.log('⚠️  HTTP请求被重定向到HTTPS: ' + req.url);
        res.writeHead(301, { 
          'Location': httpsUrl,
          'Strict-Transport-Security': 'max-age=31536000; includeSubDomains'
        });
        res.end('重定向到 HTTPS: ' + httpsUrl);
        return;
      }
    }
  }

  console.log('[' + new Date().toISOString() + '] 请求: ' + requestPath);

  // 健康检查端点
  if (requestPath === HEALTH_CHECK_PATH) {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      https_enforced: FORCE_HTTPS,
      badge_module: !!UniversalRequestClient
    }));
    return;
  }

  // 处理HTML页面请求
  if (HTML_ROUTES[requestPath]) {
    var htmlFile = HTML_ROUTES[requestPath];
    var htmlPath = path.join(__dirname, htmlFile);
    
    fs.readFile(htmlPath, 'utf8', function(err, data) {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
        var errorHtml = `
          <!DOCTYPE html>
          <html lang="zh-CN">
          <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>404 - 文件未找到</title>
            <style>
              body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
              .error { background: #fee2e2; border-left: 4px solid #ef4444; padding: 20px; border-radius: 8px; }
              h1 { color: #dc2626; margin-top: 0; }
              .file-list { background: #f3f4f6; padding: 15px; border-radius: 8px; margin-top: 15px; }
              code { background: #e5e7eb; padding: 2px 6px; border-radius: 4px; }
            </style>
          </head>
          <body>
            <div class="error">
              <h1>❌ 404 - 未找到文件: ${htmlFile}</h1>
              <p>请确保文件存在于服务器目录中</p>
            </div>
          </body>
          </html>
        `;
        res.end(errorHtml);
        console.error('❌ 读取HTML文件失败:', htmlFile, err.message);
        return;
      }
      
      var protocol = req.headers['x-forwarded-proto'] || 'https';
      var host = req.headers.host || 'localhost:' + PORT;
      var baseUrl = protocol + '://' + host;
      
      data = data.replace(/http:\/\/localhost:8080/g, baseUrl);
      
      res.writeHead(200, { 
        'Content-Type': 'text/html; charset=utf-8',
        'Strict-Transport-Security': 'max-age=31536000; includeSubDomains'
      });
      res.end(data);
      console.log('✅ 提供HTML页面: ' + requestPath + ' -> ' + htmlFile);
    });
    return;
  }

  // 📁 处理静态文件请求
  var ext = path.extname(requestPath).toLowerCase();
  if (STATIC_CONTENT_TYPES[ext]) {
    var filePath = path.join(__dirname, requestPath);
    var normalizedPath = path.normalize(filePath);
    
    if (!normalizedPath.startsWith(__dirname)) {
      res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('禁止访问');
      console.error('⛔ 非法路径访问尝试: ' + requestPath);
      return;
    }
    
    fs.readFile(filePath, function(err, data) {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('文件未找到: ' + requestPath);
        console.error('❌ 静态文件未找到: ' + requestPath);
        return;
      }
      
      res.writeHead(200, { 
        'Content-Type': STATIC_CONTENT_TYPES[ext],
        'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
        'Cache-Control': 'public, max-age=3600'
      });
      res.end(data);
      console.log('✅ 提供静态文件: ' + requestPath);
    });
    return;
  }

  // API代理部分
  if (requestPath.startsWith('/api')) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    
    if (req.method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }

    // 🆕 处理徽章查询API
    if (requestPath === '/api/badge') {
      if (!UniversalRequestClient) {
        res.writeHead(503, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ 
          success: false,
          error: '徽章查询模块未加载，请确保 api_client_version_all_app.js 文件存在'
        }));
        return;
      }

      var uuid = queryParams.uuid;
      var ticketId = queryParams.ticket_id || 'eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3MjkzMTMzNjAsInV1aWQiOiJjZmdmbHZzNTU3aW4iLCJhcHBfY29kZSI6MSwiY2xvbmVkIjoxfQ.uWniU_utqvEexV0X9TtUSUtW0jdquGPlpKbMiACiym0';

      if (!uuid) {
        res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ 
          success: false,
          error: '缺少uuid参数', 
          example: '/api/badge?uuid=xxx'
        }));
        return;
      }

      console.log('🔄 徽章查询请求: uuid=' + uuid);
      
      getBadgeInfo(uuid, ticketId)
        .then(function(result) {
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify(result));
          console.log('✅ 徽章查询成功: ' + (result.success ? '找到徽章' : result.error));
        })
        .catch(function(error) {
          console.error('❌ 徽章查询失败:', error.message);
          res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({ 
            success: false,
            error: '查询失败: ' + error.message 
          }));
        });
      return;
    }

    // 原有API端点处理
    var targetUrl = API_ENDPOINTS[requestPath];

    if (!targetUrl) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ 
        error: '未找到对应的API端点',
        available: Object.keys(API_ENDPOINTS).concat(['/api/badge'])
      }));
      return;
    }

    if (requestPath === '/api/gift' && queryParams.uuid) {
      targetUrl = targetUrl + '?host_uuid=' + queryParams.uuid;
    } else if (requestPath === '/api/gift' && !queryParams.uuid) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: '缺少uuid参数', example: '/api/gift?uuid=xxx' }));
      return;
    }

    console.log('🔄 API请求: ' + requestPath + ' -> ' + targetUrl);
    
    https.get(targetUrl, function(apiRes) {
      var data = '';
      
      apiRes.on('data', function(chunk) {
        data += chunk;
      });
      
      apiRes.on('end', function() {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(data);
        console.log('✅ API响应成功: ' + requestPath);
      });
    }).on('error', function(error) {
      console.error('❌ API请求失败:', error.message);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'API请求失败: ' + error.message }));
    });
    return;
  }

  // 其他路径重定向到首页
  res.writeHead(302, { 'Location': '/' });
  res.end();
});

process.on('SIGTERM', function() {
  console.log('收到SIGTERM信号,准备关闭服务器...');
  server.close(function() {
    console.log('服务器已关闭');
    process.exit(0);
  });
});

server.listen(PORT, '0.0.0.0', function() {
  console.log('\n========================================');
  console.log('✅ 服务器已启动！');
  console.log('🌐 监听地址: 0.0.0.0:' + PORT);
  console.log('🔒 HTTPS强制: ' + (FORCE_HTTPS ? '已启用' : '已禁用'));
  console.log('🎖️  徽章模块: ' + (UniversalRequestClient ? '已加载' : '未加载'));
  console.log('========================================');
  console.log('📄 网页访问地址:');
  console.log('   - https://17.lay666.dpdns.org/badge    → 🆕 徽章查询页面');
  console.log('   - https://17.lay666.dpdns.org           → 导航首页');
  console.log('   - https://17.lay666.dpdns.org/rank      → 主播小时榜单');
  console.log('   - https://17.lay666.dpdns.org/blindbox  → 盲盒礼物监控');
  console.log('   - https://17.lay666.dpdns.org/gift      → 礼物值监控');
  console.log('========================================');
  console.log('📡 API端点:');
  console.log('   - /api/badge    → 🆕 徽章查询API (需要?uuid=xxx)');
  console.log('   - /api/gift     → 直播间礼物值API');
  console.log('   - /api/blindbox → 盲盒礼物API');
  console.log('   - /api/rank     → 主播小时榜单API');
  console.log('   - /health       → 健康检查');
  console.log('========================================\n');
});